import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewformComponent } from './components/newform/newform.component';
import { DatadisplayComponent } from './components/datadisplay/datadisplay.component';
import { ParentComponent } from './components/parent/parent.component';


const routes: Routes = [
  {path:'', component:NewformComponent},
  {path:'dataview',component:DatadisplayComponent},
  {path:'parent',component:ParentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
