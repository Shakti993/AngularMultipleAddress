import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewformComponent } from './components/newform/newform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatadisplayComponent } from './components/datadisplay/datadisplay.component';
import { ParentdatadisplayComponent } from './components/parentdatadisplay/parentdatadisplay.component';
import { ChildComponent } from './components/child/child.component';
import { ParentComponent } from './components/parent/parent.component';


@NgModule({
  declarations: [
    AppComponent,
    NewformComponent,
    DatadisplayComponent,
    ParentdatadisplayComponent,
    ChildComponent,
    ParentComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  exports: [

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
