import { Component, OnInit, ViewChild } from '@angular/core';
import { InfoVM } from '../newform/newform'

import { ActivatedRoute } from '@angular/router';
import { log } from 'util';

@Component({
  selector: 'app-datadisplay',
  templateUrl: './datadisplay.component.html',
  styleUrls: ['./datadisplay.component.css']
})
export class DatadisplayComponent implements OnInit {
  data: any;
  info: InfoVM;
  firstname: any;
  lastname: any;
  mobile: any;
  emailnew: any;
  addressnew: any;
  newData:any;
  infoVM:InfoVM;
  private loading: boolean = false;
  
  constructor(private activatedRoute: ActivatedRoute, ) {}

  ngOnInit() {
    debugger
    this.infoVM = new InfoVM;
     this.data = localStorage.getItem('value');
     console.log(" Parse new DATA iss--",JSON.parse(this.data));
     this.newData = JSON.parse(this.data);
     this.infoVM = this.newData;
     console.log("NEW DATA ISS--",this.infoVM);
  }

}
