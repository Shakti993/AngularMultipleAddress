import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  name:string;
  data: string;
  constructor() {
    this.name = 'Angular2'
   }

  ngOnInit() {
  }

  dummyFunction(){ // I want to call this function
    this.data = "function called";
  }

}
