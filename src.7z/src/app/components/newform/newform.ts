export class AddressVM 
{
    Address:string;
    City:string;
    Country:string;
    State:string;
    CountryList:Array<any> = [];
    CityList:Array<any> = [];
    StateList:Array<any> = [];
}

export class InfoVM{
    FirstName:string;
    LastName:string;
    Mobile:string;
    Email:string;
    AddressList : Array<AddressVM>;
    
}