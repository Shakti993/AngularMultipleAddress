import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormGroupName, FormBuilder, Validators, FormArray } from '@angular/forms';
import { AddressVM, InfoVM } from './newform';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-newform',
  templateUrl: './newform.component.html',
  styleUrls: ['./newform.component.css']
})
export class NewformComponent implements OnInit {

  contactInfo: FormGroupName;
  submitted = false;
  addresstab: boolean = false;
  infoVM: InfoVM;
  addressList: Array<AddressVM> = [];
  address: AddressVM;
  data: any;
  countryvalue:any;

  /* SECOND WAY
  selectedCountry =0;
  selectedState =0;
  states=[];
  cities=[];  */


  //  ONE WAY FOR DROPDOWN CASCADING 
  countries: Array<any> = [
    {
      name: 'Germany', states: [{ name: 'GermState', cities: ['paris', 'Eibiza', 'Escborn', 'Hazlewina'] },
      { name: 'Germstate2', cities: ['Emou', 'Aukland', 'Hickieny', 'Istania'] }]
    },
    { name: 'Spain', states: [{ name: 'SpanState', cities: ['Jimiliya', 'Chreshoch', 'Hathwaw'] }] },
    { name: 'India', states: [{ name: 'IndiaState', cities: ['Delhi', 'Ahmedabad', 'Chandigarh', 'Jaipur', 'banglore'] }] },
    { name: 'USA', states: [{ name: 'USAState', cities: ['NewYork', 'LasVegas', 'Columbia', 'tampa'] }] },
    { name: 'Australia', states: [{ name: 'AustrailiaState', cities: ['Melbourne', 'Sydney', 'Okao', 'Arizona'] }] }
  ];
  states: Array<any>;
  cities: Array<any>;

  constructor(private fb: FormBuilder, private router: Router) { }

  ngOnInit() {
    // debugger
    this.infoVM = new InfoVM();
    this.infoVM.AddressList = [];
    this.address = new AddressVM();
    this.address.CountryList = this.countries;
    this.infoVM.AddressList.push(this.address);

  }

 
  changeCountry = (country, index) => {
    debugger
    console.log("COUNTRY SELECTED ISS--", country);
    this.countryvalue = country;

    // this.states = this.countries.find(cntry => cntry.name == country).states;
    console.log("States ==", this.states);

    this.infoVM.AddressList[index].StateList = this.countries.find(cntry => cntry.name == country).states;
    console.log("STATEVALUE LIST==", this.infoVM.AddressList[index].StateList);

  }

  changeState = (statevalue, index) => {
    debugger
    console.log("State selected is--", statevalue);

    // this.cities = this.countries.find(cntry => cntry.name == this.address.Country).states.find(stat => stat.name == statevalue).cities;
    // console.log("city value == iss--", this.cities);

    this.infoVM.AddressList[index].CityList = this.countries.find(cntry => cntry.name == this.countryvalue).states.find(stat => stat.name == statevalue).cities;
     console.log("CITYVALUE LIST==", this.infoVM.AddressList[index].CityList);
  }


  addAddress() {
    let address = new AddressVM();
    address.CountryList = this.countries;
    this.infoVM.AddressList.push(address);
  }

  removeAddress(i: any) {
    console.log("address list is --", this.infoVM.AddressList);
    this.infoVM.AddressList.splice(i, 1);
  }

  submitForm() {
    console.log(this.infoVM);
    // debugger
     this.data = this.infoVM;
     localStorage.setItem('value', JSON.stringify(this.data));
    // this.router.navigate(['/dataview']);
    // debugger
  }

}
