import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-parentdatadisplay',
  templateUrl: './parentdatadisplay.component.html',
  styleUrls: ['./parentdatadisplay.component.css']
})
export class ParentdatadisplayComponent implements OnInit {

  @Input() Parentdatareceived:any;
  constructor() { }

  ngOnInit() {
  }

}
