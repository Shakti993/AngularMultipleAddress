import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentdatadisplayComponent } from './parentdatadisplay.component';

describe('ParentdatadisplayComponent', () => {
  let component: ParentdatadisplayComponent;
  let fixture: ComponentFixture<ParentdatadisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParentdatadisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParentdatadisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
